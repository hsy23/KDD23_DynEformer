# VaDE-pytorch
the reproduce of Variational Deep Embedding : A Generative Approach to Clustering Requirements by pytorch

![Image](./figures/f1.png)

![Image](./figures/f2.png)

![Image](./figures/f3.png)
